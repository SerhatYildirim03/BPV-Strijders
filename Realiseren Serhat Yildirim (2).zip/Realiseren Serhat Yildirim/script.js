function showSection(sectionId) {
    const sections = document.querySelectorAll('main section');
    sections.forEach(section => {
        section.style.display = section.id === sectionId ? 'block' : 'none';
    });
}
// Badge gegevens
const badges = {
    bronze: { 
        target: 5, 
        completed: 1, 
        title: '<img src="assets/bronze_badge.png" alt="Bronze Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Lever 5 documenten in" 
    },
    silver: { 
        target: 10, 
        completed: 1, 
        title: '<img src="assets/silver_badge.png" alt="Silver Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Lever 10 documenten in" 
    },
    gold: { 
        target: 20, 
        completed: 1, 
        title: '<img src="assets/gold_badge.png" alt="Gold Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Lever 20 documenten in" 
    },
    platinum: { 
        target: 50, 
        completed: 1, 
        title: '<img src="assets/platinum_badge.png" alt="Platinum Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Lever 50 documenten in" 
    },
    
};

const notificationBadges = {
    bronze: { 
        target: 1, 
        completed: 1, 
        title: '<img src="assets/Class=3D Artist, Level=Level 1.png" alt="Bronze Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Bekijk 1 notificatie" 
    },
    silver: { 
        target: 5, 
        completed: 1, 
        title: '<img src="assets/Class=3D Artist, Level=Level 2.png" alt="Silver Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Bekijk 5 notificaties" 
    },
    gold: { 
        target: 10, 
        completed: 1, 
        title: '<img src="assets/Class=3D Artist, Level=Level 3.png" alt="Gold Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Bekijk 10 notificaties" 
    },
    platinum: { 
        target: 20, 
        completed: 1, 
        title: '<img src="assets/Class=3D Artist, Level=Level 4.png" alt="Platinum Badge" style="width: 100px; height: 100px; display: block; margin: 0 auto;">', 
        description: "Bekijk 20 notificaties" 
    }
};

// Toon badge details
function showBadgeDetails(level, type = 'document') {
    const modal = document.querySelector('.modal');
    const overlay = document.querySelector('.modal-overlay');
    
    // Reset de modal eerst
    modal.classList.remove('active');
    overlay.classList.remove('active');
    
    // Kies de juiste badge data gebaseerd op type
    const badgeData = type === 'notification' ? notificationBadges[level] : badges[level];
    
    // Bereken de voortgang
    const percentage = (badgeData.completed / badgeData.target) * 100;
    
    setTimeout(() => {
        if (percentage >= 100) {
            // Voer confetti effect uit
            triggerConfetti();
            
            modal.innerHTML = `
                <div class="achievement-complete">
                    <h2>Gefeliciteerd! 🎉</h2>
                    <p>Je hebt de ${level} badge behaald!</p>
                    ${badgeData.title}
                    <button onclick="closeModal()">Sluiten</button>
                </div>
            `;
            
            // Voeg de badge toe aan de trofeeën
            addToTrophies(level, type);
        } else {
            modal.innerHTML = `
                <div class="badge-details">
                    <h2>${level} Badge</h2>
                    ${badgeData.title}
                    <p>${badgeData.description}</p>
                    <p>Voortgang: ${badgeData.completed} / ${badgeData.target}</p>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${percentage}%"></div>
                    </div>
                    <button onclick="closeModal()">Sluiten</button>
                </div>
            `;
        }

        // Toon de modal en overlay
        modal.style.display = 'block';
        overlay.style.display = 'block';
        
        // Voeg een kleine vertraging toe voor de animatie
        requestAnimationFrame(() => {
            modal.classList.add('active');
            overlay.classList.add('active');
        });
    }, 300); // Wacht tot de vorige animatie klaar is
}

function triggerConfetti() {
    confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FFD700', '#FFA500', '#FF4500']
    });
}

function addToTrophies(level, type) {
    const badgeData = type === 'notification' ? notificationBadges[level] : badges[level];
    const trophyContainer = document.querySelector('.trophy-container') || createTrophyContainer();
    
    // Controleer of de badge al bestaat
    const existingBadge = trophyContainer.querySelector(`[data-badge="${level}-${type}"]`);
    if (!existingBadge) {
        const badgeImg = document.createElement('img');
        badgeImg.src = getBadgeImageSrc(level, type);
        badgeImg.alt = `${level} Trophy`;
        badgeImg.className = 'earned-badge';
        badgeImg.dataset.badge = `${level}-${type}`;
        trophyContainer.appendChild(badgeImg);
    }
}

function createTrophyContainer() {
    const container = document.createElement('div');
    container.className = 'trophy-container';
    container.innerHTML = '<h3>Behaalde badges:</h3><div class="earned-badges"></div>';
    document.querySelector('#Prestaties').insertBefore(container, document.querySelector('.badges-container'));
    return container;
}

function getBadgeImageSrc(level, type) {
    if (type === 'notification') {
        return `assets/Class=3D Artist, Level=Level ${getBadgeLevel(level)}.png`;
    }
    return `assets/${level}_badge.png`;
}

function getBadgeLevel(level) {
    const levels = { bronze: 1, silver: 2, gold: 3, platinum: 4 };
    return levels[level] || 1;
}

// Sluit de modaal
function closeModal() {
    const modal = document.querySelector('.modal');
    const overlay = document.querySelector('.modal-overlay');
    
    // Verwijder de active classes
    modal.classList.remove('active');
    overlay.classList.remove('active');
    
    // Wacht op de transitie en verberg dan de elementen
    setTimeout(() => {
        modal.style.display = 'none';
        overlay.style.display = 'none';
        modal.innerHTML = ''; // Maak de modal leeg
    }, 300);
}

// Render voortgangsbalk
function renderProgress(target, completed) {
    let blocks = '';
    for (let i = 1; i <= target; i++) {
        blocks += `<div class="progress-block" style="background-color: ${i <= completed ? '#4caf50' : '#ddd'};"></div>`;
    }
    return blocks;
}

function updateProgressBar(badgeId) {
    const badge = badges[badgeId];
    const percentage = (badge.completed / badge.target) * 100;
    const progressBar = document.querySelector(`[onclick="showBadgeDetails('${badgeId}')"] .progress`);
    progressBar.style.width = `${percentage}%`;
}

// Sluit modal ook wanneer op overlay wordt geklikt
document.querySelector('.modal-overlay').addEventListener('click', closeModal);

// Functie om alle voortgangsbalken bij te werken
function updateAllProgressBars() {
    Object.keys(badges).forEach(badgeId => {
        const badge = badges[badgeId];
        const percentage = (badge.completed / badge.target) * 100;
        const progressBar = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}')"] .progress`);
        if (progressBar) {
            progressBar.style.width = `${percentage}%`;
        }
    });

    Object.keys(notificationBadges).forEach(badgeId => {
        const badge = notificationBadges[badgeId];
        const percentage = (badge.completed / badge.target) * 100;
        const progressBar = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}', 'notification')"] .progress`);
        if (progressBar) {
            progressBar.style.width = `${percentage}%`;
        }
    });
}

// Functie om voortgang op te slaan
function saveProgress() {
    localStorage.setItem('documentProgress', document.getElementById('documentAantal').value);
    localStorage.setItem('notificationProgress', document.getElementById('notificationAantal').value);
}

// Functie om voortgang te laden
function loadProgress() {
    const savedDocuments = localStorage.getItem('documentProgress');
    const savedNotifications = localStorage.getItem('notificationProgress');
    
    if (savedDocuments) {
        document.getElementById('documentAantal').value = savedDocuments;
        submitDocument(savedDocuments);
    }
    
    if (savedNotifications) {
        document.getElementById('notificationAantal').value = savedNotifications;
        updateNotifications(savedNotifications);
    }
}

// Update de submitDocument functie
function submitDocument(aantal) {
    Object.keys(badges).forEach(badgeId => {
        const oldCompleted = badges[badgeId].completed;
        badges[badgeId].completed = parseInt(aantal);
        
        // Controleer of de badge nu compleet is
        if (badges[badgeId].completed >= badges[badgeId].target) {
            const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}')"]`);
            if (badgeElement && !badgeElement.querySelector('.badge-checkmark')) {
                // Als het een nieuwe voltooiing is, toon de pop-up
                if (oldCompleted < badges[badgeId].target) {
                    showBadgeDetails(badgeId);
                    triggerConfetti();
                }
                
                const checkmark = document.createElement('div');
                checkmark.className = 'badge-checkmark';
                checkmark.textContent = '✓';
                badgeElement.appendChild(checkmark);
            }
        } else {
            // Verwijder het vinkje als de voortgang onder het doel komt
            const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}')"]`);
            const checkmark = badgeElement?.querySelector('.badge-checkmark');
            if (checkmark) {
                checkmark.remove();
            }
        }
        
        // Update de voortgangsbalk
        const progressBar = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}')"] .progress`);
        if (progressBar) {
            const percentage = Math.min((badges[badgeId].completed / badges[badgeId].target) * 100, 100);
            progressBar.style.width = `${percentage}%`;
        }
    });
    
    updateBadgeTexts();
    saveProgress();
}

// Update de updateNotifications functie op dezelfde manier
function updateNotifications(aantal) {
    Object.keys(notificationBadges).forEach(badgeId => {
        const oldCompleted = notificationBadges[badgeId].completed;
        notificationBadges[badgeId].completed = parseInt(aantal);
        
        if (notificationBadges[badgeId].completed >= notificationBadges[badgeId].target) {
            const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}', 'notification')"]`);
            if (badgeElement && !badgeElement.querySelector('.badge-checkmark')) {
                if (oldCompleted < notificationBadges[badgeId].target) {
                    showBadgeDetails(badgeId, 'notification');
                    triggerConfetti();
                }
                
                const checkmark = document.createElement('div');
                checkmark.className = 'badge-checkmark';
                checkmark.textContent = '✓';
                badgeElement.appendChild(checkmark);
            }
        } else {
            const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}', 'notification')"]`);
            const checkmark = badgeElement?.querySelector('.badge-checkmark');
            if (checkmark) {
                checkmark.remove();
            }
        }
        
        const progressBar = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}', 'notification')"] .progress`);
        if (progressBar) {
            const percentage = Math.min((notificationBadges[badgeId].completed / notificationBadges[badgeId].target) * 100, 100);
            progressBar.style.width = `${percentage}%`;
        }
    });
    
    updateBadgeTexts();
    saveProgress();
}

// Voeg deze code toe aan het einde van je bestand
document.addEventListener('DOMContentLoaded', loadProgress);

// Helper functie om badge teksten bij te werken
function updateBadgeTexts() {
    // Update document badges
    Object.keys(badges).forEach(badgeId => {
        const badge = badges[badgeId];
        const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}')"]`);
        if (badgeElement) {
            const voortgangText = badgeElement.querySelector('p:nth-child(3)');
            const nogTeGaanText = badgeElement.querySelector('p:nth-child(4)');
            
            if (voortgangText && nogTeGaanText) {
                voortgangText.textContent = `Huidige voortgang: ${badge.completed}/${badge.target}`;
                nogTeGaanText.textContent = `Nog te gaan: ${Math.max(0, badge.target - badge.completed)}`;
            }
        }
    });

    // Update notification badges
    Object.keys(notificationBadges).forEach(badgeId => {
        const badge = notificationBadges[badgeId];
        const badgeElement = document.querySelector(`.badge[onclick="showBadgeDetails('${badgeId}', 'notification')"]`);
        if (badgeElement) {
            const voortgangText = badgeElement.querySelector('p:nth-child(3)');
            const nogTeGaanText = badgeElement.querySelector('p:nth-child(4)');
            
            if (voortgangText && nogTeGaanText) {
                voortgangText.textContent = `Huidige voortgang: ${badge.completed}/${badge.target}`;
                nogTeGaanText.textContent = `Nog te gaan: ${Math.max(0, badge.target - badge.completed)}`;
            }
        }
    });
}
