// Import Firebase
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database"; // Voor Realtime Database
import { getFirestore } from "firebase/firestore"; // Voor Firestore (optioneel)
import { getAuth } from "firebase/auth";

// Voeg hier je Firebase-configuratie toe (van de Firebase Console)
const firebaseConfig = {
    apiKey: "AIzaSyDn1IExUPxPNW3oiYwwIHgmhAz3KAH_NQU",
    authDomain: "gamification-bhv.firebaseapp.com",
    projectId: "gamification-bhv",
    storageBucket: "gamification-bhv.firebasestorage.app",
    messagingSenderId: "611363764405",
    appId: "1:611363764405:web:2edf8edd455ab5c46ae6fc",
    measurementId: "G-9FDXYGC4QF"
};

// Initialiseer Firebase
const app = initializeApp(firebaseConfig);

// Exporteer database-instanties
export const database = getDatabase(app); // Voor Realtime Database
export const firestore = getFirestore(app); // Voor Firestore
export const auth = getAuth(app);



