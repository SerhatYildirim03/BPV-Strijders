// Highlight active navigation link dynamically
document.addEventListener("DOMContentLoaded", () => {
    // Get the current path from the URL
    const currentPath = window.location.pathname.split("/").pop();
    // Select all navigation links
    const navLinks = document.querySelectorAll(".navbar a");

    // Loop through each link and add 'active' class if it matches the current path
    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        }
    });
});

// Dashboard: Show details in a modal
const detailButtons = document.querySelectorAll(".details-btn");

// Add click event listener to each detail button
detailButtons.forEach(button => {
    button.addEventListener("click", (event) => {
        // Find the closest table row and extract product and status information
        const row = event.target.closest("tr");
        const product = row.querySelector("td:first-child").innerText;
        const status = row.querySelector("td:nth-child(2)").innerText;

        // Show the extracted details in a modal
        showModal(`Details:\nProduct: ${product}\nStatus: ${status}`);
    });
});

// Improved modal function with TypeScript-like documentation
/**
 * @param {string} message - The message to display in the modal
 * @param {Object} options - Optional configuration object
 * @param {string} options.type - Modal type ('success', 'error', 'warning')
 * @param {number} options.duration - Auto-close duration in ms
 */
function showModal(message, options = {}) {
    // Destructure options with default values
    const { type = 'info', duration } = options;
    
    // Create modal element and set its content
    const modal = document.createElement('div');
    modal.classList.add('modal', `modal-${type}`);
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-button" role="button" aria-label="Sluiten">&times;</span>
            <div class="modal-icon ${type}-icon"></div>
            <p>${message.replace(/\n/g, '<br>')}</p>
        </div>
    `;
    document.body.appendChild(modal);

    // Improved animation with GSAP-like timing
    requestAnimationFrame(() => modal.classList.add('modal-visible'));

    // Function to close the modal
    const closeModal = () => {
        modal.classList.remove('modal-visible');
        modal.classList.add('fade-out');
        setTimeout(() => modal.remove(), 300);
    };

    // Auto-close functionality if duration is specified
    if (duration) {
        setTimeout(closeModal, duration);
    }

    // Event listeners with cleanup for closing the modal
    const closeBtn = modal.querySelector('.close-button');
    const handleClick = (e) => {
        if (e.target === modal || e.target === closeBtn) closeModal();
    };
    const handleEscape = (e) => {
        if (e.key === 'Escape') closeModal();
    };

    modal.addEventListener('click', handleClick);
    document.addEventListener('keydown', handleEscape);
}

// Improved form handling
const handleFormSubmit = (formSelector, successMessage) => {
    // Select the form using the provided selector
    const form = document.querySelector(formSelector);
    if (!form) return;

    // Add submit event listener to the form
    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        
        try {
            // Simulate an API call (replace this with actual API logic)
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Show success message in a modal
            showModal(successMessage, {
                type: 'success',
                duration: 3000
            });
            
            // Reset the form after successful submission
            form.reset();
        } catch (error) {
            // Show error message in a modal if something goes wrong
            showModal('Er is iets misgegaan. Probeer het later opnieuw.', {
                type: 'error'
            });
        }
    });
};

// Initialize form handlers
handleFormSubmit(".upload-form", "Stageproduct succesvol ingediend!");
handleFormSubmit(".review-form", "Beoordeling succesvol opgeslagen!");