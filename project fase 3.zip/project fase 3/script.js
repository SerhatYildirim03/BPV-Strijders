// Highlight active navigation link dynamically
document.addEventListener("DOMContentLoaded", () => {
    const currentPath = window.location.pathname.split("/").pop();
    const navLinks = document.querySelectorAll(".navbar a");

    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        }
    });
});

// Dashboard: Show details in a modal
const detailButtons = document.querySelectorAll(".details-btn");

detailButtons.forEach(button => {
    button.addEventListener("click", (event) => {
        const row = event.target.closest("tr");
        const product = row.querySelector("td:first-child").innerText;
        const status = row.querySelector("td:nth-child(2)").innerText;

        showModal(`Details:\nProduct: ${product}\nStatus: ${status}`);
    });
});

// Verbeterde modal functie met TypeScript-achtige documentatie
/**
 * @param {string} message - The message to display in the modal
 * @param {Object} options - Optional configuration object
 * @param {string} options.type - Modal type ('success', 'error', 'warning')
 * @param {number} options.duration - Auto-close duration in ms
 */
function showModal(message, options = {}) {
    const { type = 'info', duration } = options;
    
    const modal = document.createElement('div');
    modal.classList.add('modal', `modal-${type}`);
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-button" role="button" aria-label="Sluiten">&times;</span>
            <div class="modal-icon ${type}-icon"></div>
            <p>${message.replace(/\n/g, '<br>')}</p>
        </div>
    `;
    document.body.appendChild(modal);

    // Verbeterde animatie met GSAP-achtige timing
    requestAnimationFrame(() => modal.classList.add('modal-visible'));

    const closeModal = () => {
        modal.classList.remove('modal-visible');
        modal.classList.add('fade-out');
        setTimeout(() => modal.remove(), 300);
    };

    // Auto-close functionaliteit
    if (duration) {
        setTimeout(closeModal, duration);
    }

    // Event listeners met cleanup
    const closeBtn = modal.querySelector('.close-button');
    const handleClick = (e) => {
        if (e.target === modal || e.target === closeBtn) closeModal();
    };
    const handleEscape = (e) => {
        if (e.key === 'Escape') closeModal();
    };

    modal.addEventListener('click', handleClick);
    document.addEventListener('keydown', handleEscape);
}

// Verbeterde form handling
const handleFormSubmit = (formSelector, successMessage) => {
    const form = document.querySelector(formSelector);
    if (!form) return;

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        
        try {
            // Simuleer een API call (vervang dit door echte API logica)
            await new Promise(resolve => setTimeout(resolve, 500));
            
            showModal(successMessage, {
                type: 'success',
                duration: 3000
            });
            
            form.reset();
        } catch (error) {
            showModal('Er is iets misgegaan. Probeer het later opnieuw.', {
                type: 'error'
            });
        }
    });
};

// Form handlers initialiseren
handleFormSubmit(".upload-form", "Stageproduct succesvol ingediend!");
handleFormSubmit(".review-form", "Beoordeling succesvol opgeslagen!");