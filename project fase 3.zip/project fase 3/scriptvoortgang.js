import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getFirestore, collection, onSnapshot } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";

// Firebase Configuration
// Hier configureren we de Firebase-instellingen met de vereiste API-sleutel en andere details.
const firebaseConfig = {
    apiKey: "AIzaSyDWcf-JuR3Ea9x_sba8xEC4_EFUew3KVWg",
    authDomain: "fase-3-5822e.firebaseapp.com",
    projectId: "fase-3-5822e",
    storageBucket: "fase-3-5822e.firebasestorage.app",
    messagingSenderId: "229727350586",
    appId: "1:229727350586:web:11a97c60cf13aaf2da2a03",
    measurementId: "G-LLRXJJ2SCC"
};

// Initialize Firebase
// Initialiseer de Firebase-app en verkrijg een Firestore-instantie.
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Real-time listener to update the table dynamically
// Deze functie luistert naar wijzigingen in de 'stageproducten'-collectie en werkt de tabel bij.
function listenToProducts() {
    const tableBody = document.getElementById("product-table");
    const modal = document.getElementById("details-modal");
    const modalContent = document.getElementById("product-details");
    const closeModal = document.getElementById("close-modal");

    // Clear table and add listener
    // Maak de tabel leeg en voeg een snapshotlistener toe.
    tableBody.innerHTML = "";

    onSnapshot(collection(db, "stageproducten"), (snapshot) => {
        tableBody.innerHTML = ""; // Maak de tabel leeg

        if (snapshot.empty) {
            // Als er geen producten zijn, toon een bericht.
            tableBody.innerHTML = `
                <tr>
                    <td colspan="3">Geen producten gevonden.</td>
                </tr>
            `;
            return;
        }

        snapshot.forEach((doc) => {
            // Voor elk document in de snapshot, voeg een rij toe aan de tabel.
            const data = doc.data();
            const name = data.name || "Onbekend product";
            const status = data.status || "Nog niet beoordeeld";
            const description = data.description || "Geen beschrijving beschikbaar";
            const statusClass = status === "Goedgekeurd" ? "status-approved" : "status-pending";

            const row = `
                <tr>
                    <td>${name}</td>
                    <td><span class="${statusClass}" role="status">${status}</span></td>
                    <td><button class="details-btn" type="button" 
                        data-name="${name}" 
                        data-status="${status}"
                        data-description="${description}">Details</button></td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });

        // Setup modal handlers
        // Stel de modal handlers in voor het tonen van productdetails.
        setupModalHandlers(modal, modalContent, closeModal);
    });
}

function setupModalHandlers(modal, modalContent, closeModal) {
    // Remove existing listeners to prevent duplicates
    // Verwijder bestaande event listeners om duplicaten te voorkomen.
    document.removeEventListener('click', handleDetailsClick);
    closeModal.removeEventListener('click', handleCloseModal);
    window.removeEventListener('click', handleWindowClick);

    // Add event listener for details buttons
    // Voeg een event listener toe voor de details-knoppen.
    document.addEventListener('click', handleDetailsClick);
    
    // Close modal handlers
    // Voeg event listeners toe voor het sluiten van de modal.
    closeModal.addEventListener('click', handleCloseModal);
    window.addEventListener('click', handleWindowClick);

    function handleDetailsClick(event) {
        // Als er op een details-knop wordt geklikt, toon de productdetails in de modal.
        if (event.target.classList.contains('details-btn')) {
            const name = event.target.getAttribute('data-name');
            const status = event.target.getAttribute('data-status');
            const description = event.target.getAttribute('data-description');

            modalContent.innerHTML = `
                <h3>${name}</h3>
                <p><strong>Status:</strong> <em>${status}</em></p>
                <p><strong>Beschrijving:</strong> ${description}</p>
            `;
            modal.style.display = 'flex';
        }
    }

    function handleCloseModal() {
        // Sluit de modal wanneer de sluitknop wordt ingedrukt.
        modal.style.display = 'none';
    }

    function handleWindowClick(event) {
        // Sluit de modal wanneer er buiten de modal wordt geklikt.
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
}

// Start listening when the page loads
// Begin met luisteren naar productwijzigingen wanneer de pagina is geladen.
document.addEventListener("DOMContentLoaded", listenToProducts);
