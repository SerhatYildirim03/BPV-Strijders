import { auth } from './firebase-config.js';
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-auth.js";

document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('.register-form');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            alert('Registration successful! You can now log in.');
            window.location.href = 'inloggen.html';
        } catch (error) {
            alert(`Registration failed: ${error.message}`);
        }
    });
});
