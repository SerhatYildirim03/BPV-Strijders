import { auth } from './firebase-config.js';
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-auth.js";

document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('.login-form');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            alert('Login successful!');
            window.location.href = 'dashboard.html';
        } catch (error) {
            alert(`Login failed: ${error.message}`);
        }
    });
});
