import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyDWcf-JuR3Ea9x_sba8xEC4_EFUew3KVWg",
    authDomain: "fase-3-5822e.firebaseapp.com",
    projectId: "fase-3-5822e",
    storageBucket: "fase-3-5822e.firebasestorage.app",
    messagingSenderId: "229727350586",
    appId: "1:229727350586:web:11a97c60cf13aaf2da2a03",
    measurementId: "G-LLRXJJ2SCC"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
